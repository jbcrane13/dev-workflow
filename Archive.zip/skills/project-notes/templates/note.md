# Note: Topic Title

**Updated:** YYYY-MM-DD

## Overview

[2-3 sentences: What is this and why does it matter?]

## How It Works

[Key mechanics, flow, or architecture - can use bullet points or prose]

## Key Files

- `path/to/file.swift` - Purpose
- `path/to/other.swift` - Purpose

## Gotchas

- [Edge case or non-obvious behavior]

## Related

- ADR-N: Related decision
- L-N: Related lesson
