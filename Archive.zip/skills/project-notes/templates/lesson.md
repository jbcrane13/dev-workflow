# L-NNNN: Title

**Date:** YYYY-MM-DD
**Project:** ProjectName

## Problem

[1-2 sentences: What went wrong or was confusing?]

## Root Cause

[1-2 sentences: Why did this happen?]

## Solution

[1-2 sentences: How was it fixed?]

## Prevention

[1 sentence: How to avoid this in the future]
