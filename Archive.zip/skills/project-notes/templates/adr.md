# ADR-NNNN: Title

**Status:** Proposed
**Date:** YYYY-MM-DD

## Context

[2-3 sentences: What problem needed solving? What constraints existed?]

## Decision

[1-2 sentences: What did we decide?]

## Consequences

- (+) [Positive outcome]
- (+) [Another benefit]
- (-) [Trade-off accepted]
- (-) [Limitation or risk]
