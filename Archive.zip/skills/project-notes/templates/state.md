# Project State: ProjectName

**Updated:** YYYY-MM-DD HH:MM

## Current Phase

[Phase name and brief description]

## What's Built

- [Completed feature 1]
- [Completed feature 2]
- [Completed feature 3]

## In Progress

- [Current work item 1]
- [Current work item 2]

## Blocked

- None

## Next Up

- [Upcoming task 1]
- [Upcoming task 2]

## Technical Debt

- [Known issue 1]
- [Cleanup needed]

## Key Decisions

- ADR-1: [Brief reference]
- ADR-2: [Brief reference]
